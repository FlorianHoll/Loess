import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import time


from loess.loess import Loess

original_df = pd.read_csv("../test.csv")
data = original_df[["income", "education", "prestige"]]
data = np.array(data)

m = Loess(polynomial_degree=2)
x = np.array(original_df["women"])
y = np.array(original_df["prestige"])
m.fit(x, y)
plt.scatter(x, y)
plt.plot(np.sort(x), m.fitted_values[np.argsort(x)])
plt.show(block=True)

m = Loess(polynomial_degree=2)
x = data[:, 0]
y = data[:, 2].copy()
# original_value = y[3]
# y[3] = y[3] * 3
m.fit(x, y)
new_x = np.arange(x.min(), data[:, 0].max() + 10, 100)

tic = time.perf_counter()
pred = m.predict(new_x)
toc = time.perf_counter()
print(f"Prediction took {toc - tic:0.4f} seconds.")
plt.scatter(x, y)
plt.plot(new_x, pred)

plt.show(block=True)


x = data[:, :-1]
y = data[:, -1]
tic = time.perf_counter()
model = Loess(polynomial_degree=2)
model.fit(x, y)
toc = time.perf_counter()
print(f"Fitting took {toc - tic:0.4f} seconds.")
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 5))
pred = model.predict(x)
ax1.scatter(x[:, 0], y)
ax1.plot(np.sort(x[:, 0]), pred[np.argsort(x[:, 0])])
ax2.scatter(x[:, 1], y)
ax2.plot(np.sort(x[:, 1]), pred[np.argsort(x[:, 1])])
plt.show()

# fig = plt.figure(figsize=(20, 10))
# ax = fig.add_subplot(projection='3d')
# p = ax.plot_surface(x[:, 0], x[:, 1], model.predict(x))
# ax.set_xlabel("income")
# ax.set_ylabel("education")
# ax.set_zlabel("predictions for prestige")
# # plt.scatter(x, y)
# plt.show(block=True)

education = np.linspace(original_df.education.min(), original_df.education.max(), 25)
income = np.linspace(original_df.income.min(), original_df.income.max(), 25)
xx, yy = np.meshgrid(income, education)
new_xx_yy = np.c_[xx.ravel(), yy.ravel()]
# new_xx_yy = np.array([[4753., 8.37]])
zz = model.predict(new_xx_yy).reshape(xx.shape)

fig = plt.figure(figsize=(10, 10))
ax = fig.add_subplot(projection='3d')
p = ax.plot_surface(xx, yy, zz)
ax.set_xlabel("income")
ax.set_ylabel("education")
ax.set_zlabel("predictions for prestige")
# plt.scatter(x, y)
plt.show(block=True)
# x_order = np.argsort(x)
# plt.plot(x[x_order], model.predictions[x_order])
#
# new_x = np.arange(x.min(), x.max() + 10, 100)
#
# tic = time.perf_counter()
# pred = model.predict(new_x)
# toc = time.perf_counter()
# print(f"Prediction took {toc - tic:0.4f} seconds.")
# # plt.scatter(new_x, pred)
# plt.plot(new_x, pred)
#
# plt.show(block=True)
