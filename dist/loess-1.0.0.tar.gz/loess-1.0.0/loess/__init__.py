"""Initialize the loess package."""
from .loess import Loess
