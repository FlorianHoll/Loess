"""Not fitted error class."""


class NotFittedError(ValueError):
    """Own error class to indicate why the error was raised."""
